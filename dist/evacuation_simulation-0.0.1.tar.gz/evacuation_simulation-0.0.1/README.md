# Evacuation-Simulation

[![PyPI - Version](https://img.shields.io/pypi/v/evacuation-simulation.svg)](https://pypi.org/project/evacuation-simulation)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/evacuation-simulation.svg)](https://pypi.org/project/evacuation-simulation)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install evacuation-simulation
```

## License

`evacuation-simulation` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
